<div class="entry-podcast">
	<iframe src="<?php echo get_post_meta(get_the_ID(), 'cignited_post_podcast_embed', true) ?>">
		<a href="<?php echo get_post_meta(get_the_ID(), 'cignited_post_podcast_embed', true) ?>" target="_blank">Click here to listen to the podcast</a>
	</iframe>
</div>