<footer class="entry-footer">
	<span class="tag-links"><?php the_tags(); ?></span>
</footer> 